var app = angular.module('landing', ['appControllers', 'appServices', 'appDirectives']);
var appControllers = angular.module('appControllers', []);
var appServices = angular.module('appServices', []);
var appDirectives = angular.module('appDirectives', []);